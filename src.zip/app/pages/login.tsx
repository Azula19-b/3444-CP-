import { useState } from "react";
import { Link } from "react-router";
import { Eye, EyeOff, Mail, Lock, Chrome, Apple as AppleIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Checkbox } from "../components/ui/checkbox";

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Login", { email, password, rememberMe });
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-6 py-8">
      <div className="w-full max-w-md">
        {/* Logo & Tagline */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-green-400 to-green-600 mb-4 shadow-lg">
            <span className="text-white text-3xl font-bold">QB</span>
          </div>
          <h1 className="text-2xl font-semibold text-gray-900 mb-2">QuickBytes</h1>
          <p className="text-gray-500">Find food that fits you.</p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-5">
          {/* Email Input */}
          <div className="space-y-2">
            <Label htmlFor="email" className="text-gray-700">Email</Label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
              <Input
                id="email"
                type="email"
                placeholder="you@campus.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-12 h-14 rounded-2xl border-gray-200 bg-gray-50 focus:bg-white focus:border-green-500 transition-colors"
                required
              />
            </div>
          </div>

          {/* Password Input */}
          <div className="space-y-2">
            <Label htmlFor="password" className="text-gray-700">Password</Label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-12 pr-12 h-14 rounded-2xl border-gray-200 bg-gray-50 focus:bg-white focus:border-green-500 transition-colors"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                {showPassword ? (
                  <EyeOff className="size-5" />
                ) : (
                  <Eye className="size-5" />
                )}
              </button>
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked as boolean)}
              />
              <Label
                htmlFor="remember"
                className="text-sm text-gray-600 cursor-pointer font-normal"
              >
                Remember me
              </Label>
            </div>
            <a
              href="#"
              className="text-sm text-green-600 hover:text-green-700 font-medium"
            >
              Forgot password?
            </a>
          </div>

          {/* Login Button */}
          <Button
            type="submit"
            className="w-full h-14 rounded-2xl bg-green-500 hover:bg-green-600 text-white shadow-lg shadow-green-500/30 transition-all"
          >
            Login
          </Button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-4 my-8">
          <div className="flex-1 h-px bg-gray-200" />
          <span className="text-sm text-gray-400">Or continue with</span>
          <div className="flex-1 h-px bg-gray-200" />
        </div>

        {/* Social Login */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <Button
            type="button"
            variant="outline"
            className="h-14 rounded-2xl border-gray-200 hover:bg-gray-50 transition-colors"
          >
            <Chrome className="size-5 mr-2" />
            Google
          </Button>
          <Button
            type="button"
            variant="outline"
            className="h-14 rounded-2xl border-gray-200 hover:bg-gray-50 transition-colors"
          >
            <AppleIcon className="size-5 mr-2" />
            Apple
          </Button>
        </div>

        {/* Sign Up Link */}
        <p className="text-center text-gray-600">
          Don't have an account?{" "}
          <Link
            to="/signup"
            className="text-green-600 hover:text-green-700 font-medium"
          >
            Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
}
